package com.example.Ayubb.Capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyubbCapstoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyubbCapstoneApplication.class, args);
	}

}
