package com.example.Ayubb.Capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyubbCapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
